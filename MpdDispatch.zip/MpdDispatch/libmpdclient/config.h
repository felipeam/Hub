

/* Default MPD host */
#define DEFAULT_HOST	""

/* Default MPD port */
#define DEFAULT_PORT		6600

#define ENABLE_TCP

//#define HAVE_CURL