//
//  LibraryItems+Internals.h
//  MpdDispatch
//
//  Created by kernel on 5/07/12.
//  Copyright (c) 2012 DemoApp. All rights reserved.
//

#ifndef MpdDispatch_LibraryItems_Internals_h
#define MpdDispatch_LibraryItems_Internals_h

@interface MDLibraryItems(Internals)
- (void)loadItems:(NSArray *)songs;
@end

#endif
